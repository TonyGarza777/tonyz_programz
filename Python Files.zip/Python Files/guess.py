# File: guess.py
# Author: Antonio Garza

# Calculates overtime
import math
from random import randint


def main():
    print("Guessing Game")
    
    while True:
        print("1. Computer thinks of a number.",
              "\n2. User thinks of a number",
              "\n3. Quit\n")
        userChoice = input("Enter your selection: ")

        try:
            if userChoice == "1":
                userGuess()
            elif userChoice == "2":
                compGuess()
            elif userChoice == "3":
                break
            else:
                print("InvalidSelection")
        except:
            print("Something went wrong")

       
def compGuess():
    while True:
        try:
            smaller = int(input("Enter lower range number: "))
            larger = int(input("Enter higher range number: "))
            num = randint(smaller, larger)
            numGuesses = round(math.log(larger-smaller + 1, 2))
            count = 0

            while count < numGuesses:
                guess = (smaller + larger) // 2
                print(f"I think the number is {guess}")
                response = input("Am I correct or do I need to go", "Higher or Lower?\n>>>")

                if response.lower() in ["correct", "cor"]:
                    print(f"I win! I got it in {count} guesses.")
                    break
                elif response.lower() in ["lower", "low"]:
                    larger = guess - 1
                elif response.lower() in ["higher", "high"]:
                    smaller = guess + 1
                else:
                    print("Sorry, I dont understand.\n")

                if count == numGuesses:
                    print("LIAR!")

        except ValueError:
            print("Invalid input. Please enter integer values.")
        else:
            break



def userGuess():
    while True:
        try:
            smaller = int(input("Enter lower range number: "))
            larger = int(input("Enter Higher range number: "))
            num = randint(smaller, larger)
            numGuesses = round(math.log(larger-smaller + 1, 2))
            count = 0


            while count < numGuesses:
                try:
                    userGuess = int(input("Enter your guess: "))

                    if userGuess == num:
                        print("That's right! You win!")
                        break
                    elif userGuess < num:
                        print("Wrong! Guess higher.")
                        count += 1
                    elif userGuess > num:
                        print("Wrong! Guess lower.")
                        count += 1

                    if count == numGuesses:
                        print(f"Sorry, you are out of guesses.")
                        print(f"The number was {num}")
                except ValueError:
                    print("Invalid input. Only guess integers.")
                    count += 1
        except ValueError:
            print("Invalid input. Please enter a integer value.")
        except:
            print("Something went wrong.")
        else:
            break
            
if __name__ == "__main__":
    main()
