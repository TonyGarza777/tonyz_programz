# File name: convertit.py
# Author: Antonio Garza

# This file will convert different conversion types and numbers from one to another



def main():
	# Menu Dislay
	while True:
		# Your menu of selection has been turned into a input field to save space :3
		selection = input("""
			1) Farenheit to Celcius
			2) Celsius to Farenheit
			3) Miles to Kilometers
			4) Kilometers to Miles
			5) Pounds to Kilograms
			6) Kilograms to Pounds
			7) Degrees to Radians
			8) Radians to Degrees
			
			""")
		# If the selection is 1 the following output is shown
		if (selection == "1"):

			farenheit = eval(input("Enter the number of degrees farenheit: "))
			# The formula for it.
			celsius = (farenheit - 32) * (5 / 9)
			print(farenheit, "degrees farenheit", celsius, "degrees celsius.")


		elif (selection == "2"):
			celcius = eval(input("Enter the number of degrees farenheit: "))

			# The formula for it.
			farenheit = (9 / 5) * celsius + 32
			print(celsius, "celsius is", farenheit, "degrees farenheit.")

		elif (selection == "3"):
			# The formla for Miles to Kilometers
			miles = eval(input("Enter the number of miles: "))
			kilometers = miles * (5 / 8)
			print(miles, "miles is", kilometers, "kilometers")
		elif (selection == "4"):
			# The formula for Kilometers to Miles
			kilometers = eval(input("Enter number of Kilometers: "))
			miles = kilometers * (5 / 8)
			print(kilometers, "kilometers is", miles, "miles")
		elif (selection == "5"):
			# The formula for Pounds to Kilograms
			pounds = eval(input("Enter the number of pounds: "))
			kilograms = pounds * (201 / 443)
			print(pounds, "pounds is ", kilograms, "kilograms")
		elif (selection == "6"):
			# The formula for Kilograms into Pounds
			kilograms = eval(input("Enter number of Kilograms: "))
			pounds = kilograms * (1000 / 453)
			print(kilograms, "kilograms is", pounds, "pounds")
		elif (selection == "7"):
			# The formula for degrees into radians
			degrees = eval(input("Enter the number of degrees: "))
			radians = (degrees * 3.14) / 180
			print(degrees, "degrees is", radians, "radians")
			
		elif (selection == "8"):
			# The formula for radians into degrees
			radians = eval(input("Enter the number of radians: "))
			degrees = (radians * 180) / 3.14
			print(radians, "radians is", degrees, "degrees")

			
if __name__ == "__main__":
		main()
