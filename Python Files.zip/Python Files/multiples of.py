import os

numberOne = int(input("your number is: "))
numberTwo = int(input("The multiple of: "))
multiples = 1
result = 0

while(numberTwo >= multiples):
	# prints the numbers from the first listed by the second listed
	result = numberOne * multiples
	print(result)
	multiples = multiples + 1
input("Press any Button to Continue")
