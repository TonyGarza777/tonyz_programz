import random

# Define your ASCII art pictures
ascii_images = [
    r"""
      /\\_/\\
      ( o.o )
        > ^ <
    """,
    r"""

    /\\_/\\
    ( o.o )
    > ^ <
    """,

    r"""
    /\\_/\\
    ( o.o )
    > ^ <
    """,
    r"""

    /\\_/\\
    ( o.o )
    > ~ <
    """
]

# Print the ASCII art pictures
def print_random_ascii():
    random_image = random.choice(ascii_images)

    print(random_image)
    input("Press Any Button To Continue")
if __name__== "__main__":
    print_random_ascii()