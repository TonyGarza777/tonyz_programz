# File: fibonacci.py
# Author: Antonio Garza
# This program calculates a Fibonacci pattern

def main():
    n = int(input("Enter n: "))
    fib1 = 1
    fib2 = 1

    if n == 1 or n == 2:
        print(fib2)
    elif n > 2:
        for i in range(2, n):
            fib1, fib2 = fib2, fib1 + fib2
    else:
        print("Invalid Input")
    print("The", n, "th Fibonnaci number is:", fib2)
    

if __name__ == "__main__":
    main()



