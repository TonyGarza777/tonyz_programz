# File: ants.py
# Author: Antonio Garza

# The Ants go marching

def main():
    num = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]
    action = ["suck his thumb", "tie his shoe", "stop to pee", "close the door", "pray to survive", "pick up sticks", "eat a lemon", "try to escape", "whine", "pee again"]


    for i in range(10):
        march(num[i], action[i])

def march(num, action):

        for i in range(2):
            oneLine(num)
        print(f"The ants go marching {num} by {num}. Hurrah! Hurrah!")
        print(f"The ants go marching {num}.")
        print(f"The little one stops to {action}")
        print("And they all go marching down...")
        print("In the ground...")
        print("To get out...")
        print("Of the rain.")
        print("Boom! Boom! Boom!\n")

def oneLine(num):
        print(f"The ants go marching {num} by {num}. Hurrah! Hurrah!")

if __name__ == "__main__":
    main()
