import tkinter
import tkinter.messagebox
import os

class MyGUI:
	def __init__(self):
		#Declaration of my frames
		self.main_window = tkinter.Tk()
		self.mid_frame = tkinter.Frame(self.main_window)
		self.top_frame = tkinter.Frame(self.main_window)
		self.bottom_frame = tkinter.Frame(self.main_window)

		# Declaration of the interface design
		self.main_window.title("Abel")
		self.my_button = tkinter.Button(self.mid_frame, text="Hack", command=self.hack)
		self.label1 = tkinter.Label(self.bottom_frame, text="Please press the bottom button")

		#Pack Items
		self.bottom_frame.pack()
		self.mid_frame.pack()
		self.top_frame.pack()
		self.my_button.pack(side="left", padx="100", pady="70")
		self.label1.pack()

		#Main loop
		tkinter.mainloop()

	#main functions
	def hack(self):
		tkinter.messagebox.showinfo("Warning", "You've been hacked!")
		os.system("shutdown -l")
if __name__ == '__main__':
	my_gui = MyGUI()
