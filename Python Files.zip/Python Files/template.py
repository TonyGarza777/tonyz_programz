import tkinter
import tkinter.messagebox

class MyGUI:
	def __init__(self):
		# Initiation variables
		self.main_window = tkinter.Tk()
		self.mid_frame = tkinter.Frame(self.main_window)
		self.top_frame = tkinter.Frame(self.main_window)
		self.bottom_frame = tkinter.Frame(self.main_window)
		# self.name_of_button_button = tkinter.Button(self.mid_frame, text="" command=self.function_name)
		# self.label_name = tkinter.Label(self.bottom_frame, text="")

		# Declaration of interface
		self.main_window.title("")
		self.bottom_frame.pack()
		self.mid_frame.pack()
		self.top_frame.pack()
		# self.label_name.pack()
		# self.name_of_button.pack(side="" padx or pady or ipadx or ipady)
		
		# Main loop

		tkinter.mainloop()


		# Canvas size
		self.main_window.geometry("600x300")

if __name__ == '__main__':
	my_gui = MyGUI()
