import math

# Get the price and diameter of the pizza from the user
pizza_price = float(input("Enter the price of the pizza: $"))
pizza_diameter = float(input("Enter the diameter of the pizza (in inches): "))

# Calculate the area of the pizza
pizza_radius = pizza_diameter / 2
pizza_area = math.pi * (pizza_radius ** 2)

# Get the number of slices from the user
num_slices = int(input("Enter the number of slices: "))

# Calculate the cost per square inch
cost_per_square_inch = pizza_price / pizza_area

# per-slice
cost_per_slice = pizza_price / num_slices

# Results
print(f"Cost per square inch: ${cost_per_square_inch:.2f} per square inch")
print(f"Cost per slice: ${cost_per_slice:.2f} per slice")




