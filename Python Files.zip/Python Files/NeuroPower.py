# File: NeuroPower.py
# Author: Antonio Garza

# My first GUI

import tkinter
import tkinter.messagebox

class main:
    def __init__(self):


        # Declaration of my frames
        self.main_window = tkinter.Tk()
        self.top_frame = tkinter.Frame(self.main_window)
        self.mid_frame = tkinter.Frame(self.main_window)
        self.bottom_frame = tkinter.Frame(self.main_window)

        self.main_window.title("NeuroPower: Psychiatry")
        self.label1 = tkinter.Label(self.top_frame, text="Patient information can belisted below")
        self.my_button = tkinter.Button(self.bottom_frame, text="Submit", command=self.code)
        self.label2 = tkinter.Label(self.bottom_frame, text="", relief="sunken")
        # lbl = tkinter.Label(self.main_window, text = "Enter the name:").grid(column = 0, row = 0)# Click event  
        # def click():   
        #    print("Hi," + name.get())# Textbox widget  
##        name = tkinter.StringVar()  
##        nameEntered = tkinter.Entry(self.main_window, width = 12, textvariable = name).grid(column = 0, row = 1) 
        # Track selected  radio button
        self.radio_var = tkinter.IntVar()

        # create radio buttons
        self.radio_button1 = tkinter.Radiobutton(self.mid_frame, text="Male", value=1)
        self.radio_button2 = tkinter.Radiobutton(self.mid_frame, text="Female", value=2)

        # Pack items
        self.top_frame.pack(side="top")
        self.mid_frame.pack()
        self.bottom_frame.pack(side="bottom")
        self.radio_button1.pack(side="left")
        self.radio_button2.pack(side="right")
        self.my_button.pack(side="top")
        self.label1.pack()
        self.label2.pack(pady="10", ipadx="200", ipady="50")
        self.main_window.geometry("600x300")

        #Main loop
        tkinter.mainloop()

        
    def code(self):
        # name, age, gender
        # name = str(input("Please Enter the Patinent Name: "))
        # age = int(input("Please Enter the Patient Age: "))
        # interpolation,  then print
        populateArr = ["name = ",name , "Age= ", age, "Sex= ", sex]
        print(populateArr)
        populateArr = self.label2

if __name__ == "__main__":
    main()
