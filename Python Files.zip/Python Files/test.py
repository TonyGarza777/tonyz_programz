x = 5
y = 3
z = -2
w = x(y + z)
