# File: mortgage.py
# Author: Antonio Garza

# This program takes inputs and approves mortgages or loans

def main():

    another = True

    while another:

        try:
            amount = float(input("How much moneu do you want?\n>>> "))
            years = int(input("How long till you pay us back?\n>>> "))
            print()

            if amount < 10000000:
                annualIncome = float(input("Enter your annual income: "))
                downpayment = float(input("Enter your down payment: "))
                creditScore = int(input("Enter your credit score: "))

                monthlyIncome = annualIncome / 12
                monthlyPayment = monthlyIncome * 0.25

                approvedAmount = monthlyPayment * 12 * years

                if amount - downpayment <= approvedAmount:
                    if creditScore >= 750:
                        print(f"You are approved for ${amount:.2f}")
                    else:
                        print("Get lost you peasant. Your credit sucks!")
                else:
                    print("How do you expect to be able to pay for this loan?")
                    print("You could only afford $", round(approvedAmount, 2))
            else:
                print("What are you crazy?")
            choice = input("Would you like to apply for another loan? (Yes or No): ")

            if choice.lower() == "No" or choice.lower() == "n":
                another = False
        except ValueError:
            print("Invalid Response")
        except:
            print("Something went wrong. No idea what happened")
            
                

                
if __name__ == "__main__":
    main()
