

def main():
    data = []
    guestLimit = 0
    enterInfo = """  Wedding guest menu
                                1) Guest Name Press '1'
                                2) Add a Guest press '2'
                                3) Delete Guest Name '3'

                                if you have any questions call '555-5555'

                             """
    # First actual program inputs
    guestName = input("Please enter the name of the guest: ")
    guestAge = input("Please enter the age of the guest: ")
    data.append(guestName)
    data.append(guestAge)
                    
        # f string that prints guest name and age
    print(f"Your guest name is  {guestName} your guest age is {guestAge}")
        
    # While loop
    while True:
        print(enterInfo)
        choice = input("ENTER ONE OF THE FOLLOWING CHOICES: ")
        if choice == "1":
            # Prints the list up above\
            print(data)
        elif choice == "2":
            # First function
            mainInput()
            # Add Person
            data.append(guestName)
            data.append(guestAge)
        elif choice == "3":
            mainInput()
            data.remove(guestName)
            data.remove(guestAge)
    # choice = input("ENTER A FOLLOWING CHOICE: ")

def mainInput():
    guestName = input("Please enter the name of the guest: ")
    guestAge = input("Please enter the age of the guest: ")

if __name__ == "__main__":
    main()

        
		

