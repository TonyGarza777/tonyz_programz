# File: blackjack.py
# Author: Antonio Garza

# Simulates the game BlackJack

import random

def main():
    userChoice = displayInput()
    deck = shuffle()

    if userChoice == "1":
        play(deck)
    elif userChoice == "2":
        sim(deck)
    elif userChoice == "3":
        break

def sim(deck):
    balance = getBalance()
    bet = getBet(balance)
    wins = 0
    loses = 0
    draws = 0
    count = 0
    maxBalance = balance

    while balance > 0:
        count += 1
        result = simOneHand(deck)

        if len(deck) < 25:
            deck = shuffle()


        if result == True:
            balance += bet
            wins += 1
        elif result == False:
            balance -= bet
            loses += 1
        else:
            draws += 1

        print(balance)
        if balance > maxBalance:
            maxBalance = balance
        elif balance <= 0:
            print(f"Player ran out of money after {count} hands")
            print(f"They had {maxBalance}")
            print(f"Wins: {wins}, Loses: {loses}, Draws: {draws}")

def simOneHand():

    try:
        dealerTotal = 0
        playerTotal = 0

        playerTotal += deck.pop()
        dealerTotal += deck.pop()
        playerTotal += deck.pop()
        dealerTotal += deck.pop()


        while True:

            if playerTotal < 15:
               playerTotal += deck.pop()
               if playerTotal > 21:
                   return False
            else:
                break

        while dealerTotal < 17:
            dealerTotal += deck.pop()
            if dealerTotal > 21:
                return True


        if playerTotal > dealerTotal:
            return True
        elif dealerTotal > playerTotal:
            return False
        else:
            return "Draw"
        
    except:
        print("Error")
        
def play(deck):

    balance = getBalance()
    count = 0
    maxBalance = balance

    while balance > 0:
        bet = getBet(balance)
        count+= 1
        result = playOneHand(deck)

        if result == True:
            balance += bet
        elif result == False:
            balance -= bet

        if balance > maxBalance:
            maxBalance = balance
            choice = input("Keep going or, Quit")
            if choice.lower() == "yes":
                break
        elif balance <= 0:
            print("You're out of money.")

def playOneHand(deck):
        try:
            dealerTotal = 0
            playerTotal = 0

            playerTotal += deck.pop()
            dealerTotal += deck.pop()
            playerTotal += deck.pop()
            dealerTotal += deck.pop()

            print(f"Dealer has: {dealerTotal}")
            print(f"Player has: {playerTotal}")

            while True:
                choice = input("Hit or stand?\n>>> ")
                if choice.lower() == "hit":
                    playerTotal += deck.pop()
                    print(f"Palyer has {playerTotoal}")
                    if playerTotal > 214:
                        print("You bust!")
                        return False
                elif choice.lower() == "stand":
                    break
                else:
                    print("What?")

            while dealerTotal < 17:
                dealerTotal += deck.pop()
                if dealerTotal > 21:
                    print("You win!")
                    return True

            print(f"Dealer has: {dealerTotal}")
            print(f"Player has: {playerTotal}")

            if playerTotal > dealerTotal:
                print("You win the hand")
                return True
            elif dealerTotal > playerTotal:
                print("You lose the hand")
                return False
            else:
                return "Draw"
        except:
          print("Error!")

def getBet():
    while True:
        try:
            bet = float(input("Enter your wager.\n>>>"))
            if bet > balance:
                print("You don't have that much money.")
            else:
                return bet
        except ValueError:
            print("Stop messing around and give me an actual bet.")
        except:
            print("You are a disaster.")

    
def getBalance():
    while True:
        try:
            balance = float(input("Enter your wager. \n>>> "))
            return balance
        except ValueError:
            print("That isn't a legitimate amount of money.")
            
def shuffle():
    deck = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11]

##    for i in range(4):
##        for rank in range(2, 12):
##            deck.append(rank)
##        for j in range(3):
##           deck.append(10)

    deck = random.sample(deck, len(deck))

    return deck


def displayInput():
    while True:
        try:
            welcomeMsg = int(input("""
                Welcome to BlackJack.
                Do you want to..?
                1.) Play BlackJack
                2.) Sim BlackJack
                3.) Quit
            """))

            if welcomeMsg in ["1", "2", "3"]:
                return welcomeMsg
            else:
                print("I dont know what that means")
        except:
            print("Error Code 10345777")


if __name__ == "__main__":
    main()
