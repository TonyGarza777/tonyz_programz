import math

def main():
    distance = float(input("Enter the distance from you to the building (in feet): "))
    angleToTop = float(input("Enter the angle to the top of the building (in degrees): "))

    height = math.tan(math.radians(angleToTop)) * distance
    print("The estimated height of the building is:", round(height, 2))
    ladderAngle = float(input("Enter the angle of the ladder (in degrees): "))

    length = height / math.sin(math.radians(ladderAngle))

    print(f"The length of the ladder is: {length:.2f} feet")

if __name__ == "__main__":
    main()