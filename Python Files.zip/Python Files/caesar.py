# File: Caesar.py
# Author: Antonio Garza

# This program gives the user the option to encrypt or encrypt or decrypt a file

from tkinter.filedialog import askopenfilename

def main():
    keepGoing = True
    while keepGoing:
        
        choice = input("""

            1. Encrypt\n
            2. Decrypt\n
            3. exir
            Enter your choice (1, 2 or 3):

            """)
        if choice == "1":
            fileName = askopenfilename()
            myFile = open(fileName, 'r')
            encrypt(myFile)
        elif choice == "2":
            fileName = askopenfilename()
            myFile = open(fileName, 'r')
            decrypt(myFile)
        elif choice == "3":
            keepGoing = False
        else:
            print("Invalid Selection")

        
def encrypt(myFile):
    key = 10
    encryptedString = ""

    for line in myFile:
        for ch in line.strip():
            encLetter = ord(ch) + key
            if encLetter > 126:
                encLetter = (encLetter % 126) + 32
            encLetter = chr(encLetter)
            encryptedString += encLetter
        encryptedString += "\n"
    print(encryptedString)
    myFile.close()
    fileName = input("Enter a file name: ")
    newFile = open(fileName, 'w')
    newFile.write(encryptedString)
    newFile.close()


                

def decrypt(myFile):
    key = 10
    decryptedString = ""

    for line in myFile:
        for ch in line.strip():
            decLetter = ord(ch) - key
            if decLetter < 32:
                decLetter = 126 - (32 - decLetter)

            decLetter = chr(decLetter)
            decryptedString += decLetter
        decryptedString += "\n"
    print(decryptedString)

    myFile.close()

    fileName = input("Enter a file name: ")
    newFile.open(fileName, 'w')
    newFile.write(decryptedString)
    newFile.close()


if __name__ == "__main__":
    main()
