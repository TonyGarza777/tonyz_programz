# File: turtlePower.py
# Author: Antonio Garza

# Drawing program

import turtle
from random import *

def main():
    width, height = turtle.screensize()
    fred = turtle.Turtle()
    fred.screen.colormode(255)
    fred.screen.bgcolor("black")
    fred.shape("turtle")
    fred.pencolor(randint(0, 255), randint(0, 255), randint(0, 255))
    fred.speed(10)

    #walk(fred, width, height)
    spiral(fred)
    
def walk(fred, width, height):
    length = 25
    angle = 90
    left_right = 0
    iterate = 1000

    for i in range(iterate):
        fred.fd(length)
        fred.pencolor(randint(0, 255), randint(0, 255), randint(0, 255))
        fred.fillcolor(randint(0, 255), randint(0, 255), randint(0, 255))
        x, y = fred.pos()
        if (x > width or x < -(width) or y > height or y < -(height)):
            fred.up()
            fred.setposition(randint(-width, width), randint(-height, height))
            fred.down()
        left_right = randint(0, 1)

        if left_right == 0:
            fred.right(angle)
        else:
            fred.left(angle)

def spiral(fred):

    for i in range(500):
        r = randint(0, 255)
        g = randint(0, 255)
        b = randint(0, 255)

        fred.pencolor(r, g, b)
        fred.fillcolor(r, g, b)

        for y in range(4):
            fred.fd(i + 25)
            fred.rt(90)

        fred.rt(5)


if __name__== "__main__":
    main()
