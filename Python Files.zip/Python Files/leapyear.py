# File: overtime.py
# Author: Antonio Garza

# Calculates overtime

def main():
    print("Pay Calculator")
    another = True

    while another:
        try:
            hours = float(input("Enter hours worked: "))
            rate = float(input("Enter hourly pay rate: "))
            pay = 0.0

            if hours > 40.0:
                pay = 40 * rate
                pay += (rate * 1.5) * (hours - 40)
            else:
                pay = hours * rate

            print(f"Your pay for this week will be: ${pay:.2f}\n")
            choice = input("Would you like to enter another week's pay? (Yes or No): ")

            if choice.lower() == "no" or choice.lower() == "n":
                another = False
        except ValueError as exc:
            print(exc)
            print("Invalid Input")
        except:
            print("Error!")

        else:
            print("Success!")

            
if __name__ == "__main__":
    main()
