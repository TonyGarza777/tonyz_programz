import random

# Define your ASCII art pictures
catOne = [
    r"""
      /\\_/\\
      ( o.o )
        > ^ <
    """
 ]
catTwo = [
    """

    /\\_/\\
    ( o.o )
    > ^ <
    """
]
catThree = [
    """
    /\\_/\\
    ( o.o )
    > ^ <
    """
]
catFour = [
    """
    /\\_/\\
    ( o.o )
    > ~ <
    """
]

# Print the ASCII art pictures
list = [catOne, catTwo, catThree, catFour]
random_image = random.choice(list)

print(random_image)

if __name__== "__main__":
    print_random_ascii()
